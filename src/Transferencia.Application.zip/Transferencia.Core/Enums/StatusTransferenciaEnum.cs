﻿namespace Transferencia.Core.Enums
{
    public enum StatusTransferenciaEnum
    {
        Sucesso,
        Falha,
        Pendente,
        Cancelada
    }
}
