﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Transferencia.Application.Interfaces;

namespace Transferencia.Api.Filters
{
    //public class ApiResponseFilter : IActionFilter
    //{
    //    public void OnActionExecuting(ActionExecutingContext context) { }

    //    public void OnActionExecuted(ActionExecutedContext context)
    //    {
    //        if (context.Result is ObjectResult result)
    //        {
    //            var statusCode = result.StatusCode ?? 200;

    //            // Cria a resposta encapsulada, mas não toca nos cabeçalhos
    //            var apiResponse = new ObjectResult(ApiResponse<object>.SuccessResponse(result.Value))
    //            {
    //                StatusCode = statusCode
    //            };

    //            // Substitui o resultado com a resposta encapsulada
    //            // Preserva os cabeçalhos existentes
    //            context.HttpContext.Response.StatusCode = statusCode;
    //            context.Result = apiResponse;
    //        }
    //    }
    //}

}