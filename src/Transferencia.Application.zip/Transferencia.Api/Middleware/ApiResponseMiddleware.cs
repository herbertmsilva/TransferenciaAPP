﻿using System.Text.Json; // Importa o namespace para System.Text.Json
using Transferencia.Application.Interfaces;

namespace Transferencia.Api.Middleware
{
    public class ApiResponseMiddleware
    {
        private readonly RequestDelegate _next;

        public ApiResponseMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Cria um novo MemoryStream para armazenar a resposta temporariamente
            using (var memoryStream = new MemoryStream())
            {
                var originalBodyStream = context.Response.Body;
                context.Response.Body = memoryStream;

                try
                {
                    // Continua o pipeline de solicitação
                    await _next(context);

                    // Reseta o stream para o início
                    memoryStream.Seek(0, SeekOrigin.Begin);

                    // Lê o corpo da resposta
                    var responseBody = await new StreamReader(memoryStream).ReadToEndAsync();

                    // Cria o objeto ApiResponse
                    var apiResponse = new ApiResponse<object>
                    {
                        Success = context.Response.StatusCode >= 200 && context.Response.StatusCode < 300,
                        Data = responseBody.Length > 0 ? JsonSerializer.Deserialize<object>(responseBody) : null,
                        Error = null
                    };

                    // Escreve o ApiResponse de volta ao fluxo de resposta original
                    context.Response.Body = originalBodyStream;
                    context.Response.ContentType = "application/json";

                    var jsonResponse = JsonSerializer.Serialize(apiResponse); // Usando System.Text.Json para serialização
                    await context.Response.WriteAsync(jsonResponse);
                }
                catch (Exception ex)
                {
                    context.Response.Body = originalBodyStream;
                    throw;
                }
            }
        }
    }
}
